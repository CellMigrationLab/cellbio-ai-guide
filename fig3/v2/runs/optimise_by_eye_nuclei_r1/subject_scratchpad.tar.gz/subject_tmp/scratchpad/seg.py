import tifffile,numpy as np,time,sys
from cellpose import models
a=tifffile.imread('image.tif').astype('float32')
lo,hi=np.percentile(a,[1,99.5]); x=np.clip((a-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
for d in [None,23]:
    t=time.time()
    l=m.eval(x,diameter=d,batch_size=4)[0]
    np.save(f'{sys.argv[1]}/l_{d}.npy',l);print(d,l.max(),time.time()-t)
