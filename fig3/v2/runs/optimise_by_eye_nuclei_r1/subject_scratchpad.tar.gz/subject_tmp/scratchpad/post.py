import numpy as np,tifffile
from scipy import ndimage as ndi
from skimage import measure,morphology
a=tifffile.imread('image.tif').astype(float)
l=np.load(f'{S}/l_None.npy') if False else None
