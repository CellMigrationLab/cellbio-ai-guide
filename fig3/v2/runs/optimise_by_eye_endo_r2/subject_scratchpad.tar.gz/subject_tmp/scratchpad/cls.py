import os;S=os.environ['S']
import numpy as np,tifffile
from scipy import ndimage as ndi
from skimage import io,segmentation
from skimage.measure import regionprops
a=tifffile.imread('image.tif').astype(np.float32)
def norm(h):
    h=h-ndi.gaussian_filter(h,40);lo,hi=np.percentile(h,[1,99]);return np.clip((h-lo)/(hi-lo),0,1)
x=np.concatenate([norm(a[:,:512]),norm(a[:,512:])],1)
lab=np.load(S+'/lab50.npy')
r=regionprops(lab,x)
sd=np.array([p.image_intensity[p.image].std() for p in r]);ar=np.array([p.area for p in r])
print(np.percentile(sd,[5,25,50,75,90,95]))
import sys;T=float(sys.argv[1])
rgb=np.dstack([x]*3)
for p,s in zip(r,sd):
    m=lab==p.label
    b=segmentation.find_boundaries(m)
    rgb[b]=[0,1,0] if s>T else [1,0,0]
io.imsave(S+'/cls.png',(rgb*255).astype('uint8'))
print((sd>T).sum())
