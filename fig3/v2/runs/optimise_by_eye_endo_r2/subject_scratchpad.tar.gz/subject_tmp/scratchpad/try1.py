import os;S=os.environ['S']
import tifffile,numpy as np,time,sys
from scipy import ndimage as ndi
from skimage import io,segmentation
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
def norm(h):
    bg=ndi.gaussian_filter(h,40); h=h-bg
    lo,hi=np.percentile(h,[1,99]);return np.clip((h-lo)/(hi-lo),0,1)
x=np.concatenate([norm(a[:,:512]),norm(a[:,512:])],1)
m=models.CellposeModel(gpu=False)
for d in [50]:
    t=time.time()
    r=m.eval(x,diameter=d,normalize=False,flow_threshold=0.4,cellprob_threshold=0.0)
    lab=r[0];print(d,lab.max(),time.time()-t)
    np.save(f'{S}/lab{d}.npy',lab)
    b=np.clip(x,0,1);rgb=np.dstack([b]*3)
    rgb[segmentation.find_boundaries(lab)]=[1,0,0]
    io.imsave(f'{S}/ov{d}.png',(rgb*255).astype('uint8'))
