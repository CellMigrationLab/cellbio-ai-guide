import time,numpy as np,tifffile
from scipy import ndimage as ndi
from skimage import transform,exposure
from cellpose import models
S='/tmp/claude-0/-home-user-sessions-v2-v052/fcd8c227-2fbb-4fb0-823d-9b64b343667d/scratchpad/w/'
im=tifffile.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(im,40);sd=np.sqrt(ndi.gaussian_filter((im-bg)**2,40));f=(im-bg)/sd
m=models.CellposeModel(gpu=False)
def run(name,img,scale,cpt,ft=0.4):
    s=transform.rescale(img,scale,order=1,anti_aliasing=True).astype(np.float32)
    lab,_,_=m.eval(s,flow_threshold=ft,cellprob_threshold=cpt,normalize={'normalize':True})
    lab=transform.resize(lab,im.shape,order=0,preserve_range=True,anti_aliasing=False).astype(np.int32)
    tifffile.imwrite(S+name+'.tif',lab);print(name,lab.max(),flush=True)
c=exposure.equalize_adapthist(exposure.rescale_intensity(f,in_range=(-3,3),out_range=(0,1)),kernel_size=64,clip_limit=0.02).astype(np.float32)
run('v_clahe_0.5',c,0.5,0.0)
run('v_cp-2_0.5',f,0.5,-2.0)
run('v_ft0.8_0.5',f,0.5,-1.0,0.8)
