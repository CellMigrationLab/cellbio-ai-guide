import sys,tifffile,numpy as np
exec(open('/tmp/claude-0/-home-user-sessions-v2-v052/fcd8c227-2fbb-4fb0-823d-9b64b343667d/scratchpad/w/post.py').read().split("l=tifffile")[0])
gt=tifffile.imread('annotation.tif')
exec("def ringstd"+open(S+'post.py').read().split("def ringstd")[1].split("rs=ringstd")[0])
K=('F1@0.5','n_pred','area_med_pred','AR_med_pred','matched_area_relerr_med%','matched_AR_abserr_med','AR_spearman')
for n in sys.argv[1:]:
    l=tifffile.imread(S+n+'.tif');rs=ringstd(l)
    for thr in [1.0,1.2]:
      for exp in [6,10]:
        k=np.array([i for i,v in rs.items() if v<thr]);p=segmentation.expand_labels(np.where(np.isin(l,k),l,0),exp)
        p,_,_=segmentation.relabel_sequential(p);r=evaluate(p.astype(np.int32),gt)
        print(n,thr,exp,[round(float(r[a]),2) for a in K])
