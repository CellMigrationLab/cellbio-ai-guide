import sys,time,numpy as np,tifffile
from scipy import ndimage as ndi
from skimage import transform
from cellpose import models
S='/tmp/claude-0/-home-user-sessions-v2-v052/fcd8c227-2fbb-4fb0-823d-9b64b343667d/scratchpad/w/'
im=tifffile.imread('image.tif').astype(np.float32)
def flat(im,sig=40):
    bg=ndi.gaussian_filter(im,sig); sd=np.sqrt(ndi.gaussian_filter((im-bg)**2,sig))
    return (im-bg)/sd
m=models.CellposeModel(gpu=False)
for scale in [0.5,0.75]:
    f=flat(im)
    s=transform.rescale(f,scale,order=1,anti_aliasing=True).astype(np.float32)
    t=time.time()
    lab,_,_=m.eval(s,diameter=None,flow_threshold=0.4,cellprob_threshold=0.0,niter=None,normalize={'normalize':True})
    print(scale,lab.max(),time.time()-t,flush=True)
    lab=transform.resize(lab,im.shape,order=0,preserve_range=True,anti_aliasing=False).astype(np.int32)
    tifffile.imwrite(S+f'lab_{scale}.tif',lab)
