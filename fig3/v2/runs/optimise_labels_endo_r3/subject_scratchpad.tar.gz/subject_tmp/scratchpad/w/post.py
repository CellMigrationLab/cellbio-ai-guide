import sys,tifffile,numpy as np
from scipy import ndimage as ndi
from skimage import measure,segmentation
sys.path.insert(0,'/tmp/claude-0/-home-user-sessions-v2-v052/fcd8c227-2fbb-4fb0-823d-9b64b343667d/scratchpad/w')
from evalseg import evaluate
S='/tmp/claude-0/-home-user-sessions-v2-v052/fcd8c227-2fbb-4fb0-823d-9b64b343667d/scratchpad/w/'
im=tifffile.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(im,40);sd=np.sqrt(ndi.gaussian_filter((im-bg)**2,40));f=(im-bg)/sd
l=tifffile.imread(S+'lab_0.5.tif');gt=tifffile.imread('annotation.tif')
def ringstd(l):
    out={}
    for r in measure.regionprops(l):
        sl=tuple(slice(max(s.start-5,0),s.stop+5) for s in r.slice)
        m=l[sl]==r.label
        ring=ndi.binary_dilation(m,iterations=3)&~ndi.binary_erosion(m,iterations=3)
        out[r.label]=f[sl][ring].std()
    return out
rs=ringstd(l)
for thr in [0.8,1.0,1.2]:
  for exp in [0,8,15,25]:
    k=np.array([i for i,v in rs.items() if v<thr]);keep=np.isin(l,k)
    p=np.where(keep,l,0)
    if exp: p=segmentation.expand_labels(p,exp)
    p,_,_=segmentation.relabel_sequential(p)
    r=evaluate(p.astype(np.int32),gt)
    print(thr,exp,{a:round(float(b),2) for a,b in r.items() if a in('F1@0.5','F1@0.75','n_pred','area_med_pred','AR_med_pred','matched_area_relerr_med%','matched_AR_abserr_med','AR_spearman','fg_frac_pred')})
