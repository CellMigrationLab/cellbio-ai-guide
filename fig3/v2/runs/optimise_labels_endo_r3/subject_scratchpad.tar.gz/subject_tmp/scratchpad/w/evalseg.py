import sys,numpy as np,tifffile
from skimage import measure,segmentation,io,exposure
PX=0.65
def props(l):
    return {r.label:(r.area*PX**2, r.major_axis_length/max(r.minor_axis_length,1e-6)) for r in measure.regionprops(l)}
def evaluate(pred,gt,border=10):
    # exclude GT/pred objects touching the image border from stats
    ids_g=np.unique(gt)[1:]; ids_p=np.unique(pred)[1:]
    ov=np.zeros((ids_g.max()+1,ids_p.max()+1),np.int32)
    m=(gt>0)&(pred>0)
    np.add.at(ov,(gt[m],pred[m]),1)
    ag=np.bincount(gt.ravel(),minlength=ov.shape[0]);ap=np.bincount(pred.ravel(),minlength=ov.shape[1])
    iou=ov/(ag[:,None]+ap[None,:]-ov+1e-9)
    res={}
    for t in (0.5,0.75):
        tp=0;pairs=[]
        for g in ids_g:
            p=iou[g].argmax()
            if iou[g,p]>=t and p>0 and iou[:,p].argmax()==g: tp+=1;pairs.append((g,p))
        res[f'F1@{t}']=2*tp/(len(ids_g)+len(ids_p))
        if t==0.5: pr50=pairs
    pg,pp=props(gt),props(pred)
    ga=np.array([pg[g][0] for g,_ in pr50]);pa=np.array([pp[p][0] for _,p in pr50])
    gr=np.array([pg[g][1] for g,_ in pr50]);pr=np.array([pp[p][1] for _,p in pr50])
    res['n_gt']=len(ids_g);res['n_pred']=len(ids_p)
    res['count_err%']=100*(len(ids_p)-len(ids_g))/len(ids_g)
    res['area_med_gt']=np.median([v[0] for v in pg.values()]);res['area_med_pred']=np.median([v[0] for v in pp.values()])
    res['AR_med_gt']=np.median([v[1] for v in pg.values()]);res['AR_med_pred']=np.median([v[1] for v in pp.values()])
    res['matched_area_relerr_med%']=100*np.median(np.abs(pa-ga)/ga)
    res['matched_AR_abserr_med']=np.median(np.abs(pr-gr))
    res['AR_spearman']=float(__import__('scipy.stats').stats.spearmanr(gr,pr)[0])
    res['fg_frac_gt']=(gt>0).mean();res['fg_frac_pred']=(pred>0).mean()
    return res
if __name__=='__main__':
    gt=tifffile.imread('/home/user/sessions_v2/v052/annotation.tif')
    for f in sys.argv[1:]:
        r=evaluate(tifffile.imread(f).astype(np.int32),gt)
        print(f);[print('  ',k,round(float(v),3)) for k,v in r.items()]
