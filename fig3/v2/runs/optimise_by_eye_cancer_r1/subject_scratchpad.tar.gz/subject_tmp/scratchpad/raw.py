import sys; sys.path.insert(0,'/home/user/sessions_v2/v066')
import pipeline as p, numpy as np, tifffile as t
img=p.load_image('image.tif'); m=p.run_cellpose(p.normalise(img)); t.imwrite(sys.argv[1],m.astype('int32')); print(m.max())
