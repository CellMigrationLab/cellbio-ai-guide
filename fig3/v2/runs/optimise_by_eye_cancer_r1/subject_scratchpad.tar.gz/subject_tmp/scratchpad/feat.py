import sys; sys.path.insert(0,'/home/user/sessions_v2/v066')
import pipeline as p, numpy as np, tifffile as t
from scipy import ndimage as ndi
from skimage import measure, morphology
img=t.imread('image.tif').astype(float); n=p.normalise(img.astype('uint16'))
L=t.imread(sys.argv[1]); g=ndi.gaussian_gradient_magnitude(n,1.0)
for r in measure.regionprops(L):
    m=L==r.label
    ring=morphology.binary_dilation(m,morphology.disk(2))&~morphology.binary_erosion(m,morphology.disk(2))
    print(r.label,int(r.centroid[0]),int(r.centroid[1]),int(r.area),round(r.solidity,2),round(g[ring].mean(),2),round(np.percentile(n[ring],5),2),round(n[ring].std(),2),round(n[m].std(),2))
