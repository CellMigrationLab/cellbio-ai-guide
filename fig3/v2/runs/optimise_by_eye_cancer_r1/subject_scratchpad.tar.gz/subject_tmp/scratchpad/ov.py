import sys,tifffile as t,numpy as np
from skimage import io,segmentation
a=t.imread('image.tif').astype(float);L=t.imread(sys.argv[1])
b=np.zeros_like(a)
for x in (0,512):
    s=a[:,x:x+512];lo,hi=np.percentile(s,[0.5,99.5]);b[:,x:x+512]=np.clip((s-lo)/(hi-lo),0,1)
rgb=np.dstack([b]*3);bd=segmentation.find_boundaries(L,mode='outer')
rgb[bd]=[1,0,0]
from skimage.transform import resize
io.imsave(sys.argv[2],(np.kron(rgb,np.ones((1,1,1)))*255).astype('uint8'))
