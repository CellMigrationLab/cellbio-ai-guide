import sys; sys.path.insert(0,'/home/user/sessions_v2/v066')
import pipeline as p, numpy as np, tifffile as t
img=p.load_image('image.tif'); n=p.normalise(img); m=t.imread(sys.argv[1])
l=p.filter_objects(p.trim_leaks(p.filter_by_contrast(p.fill_and_clean(m),n)))
t.imwrite(sys.argv[2],l.astype('uint16')); print(l.max())
