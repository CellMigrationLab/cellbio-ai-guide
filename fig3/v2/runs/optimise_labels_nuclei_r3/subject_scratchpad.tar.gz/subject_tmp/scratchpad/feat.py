import numpy as np,tifffile as t,sys
sys.path.insert(0,'.')
from evaluate import match
from skimage.measure import regionprops
from scipy import ndimage as ndi
im=t.imread('image.tif').astype(float);pr=t.imread(sys.argv[1]).astype(np.int64);gt=t.imread('annotation.tif').astype(np.int64)
tp={b for _,b,_ in match(gt,pr)}
import pandas as pd
rows=[]
for r in regionprops(pr,im):
    m=pr==r.label if False else None
    rows.append(dict(l=r.label,tp=r.label in tp,area=r.area,mean=r.intensity_mean,mx=r.intensity_max,sol=r.solidity,ar=r.axis_major_length/r.axis_minor_length,ecc=r.eccentricity,sd=np.std(r.image_intensity[r.image])/r.intensity_mean))
d=pd.DataFrame(rows);pd.set_option('display.width',200)
print(d.groupby('tp').describe().T.to_string())
d.to_pickle(sys.argv[2])
