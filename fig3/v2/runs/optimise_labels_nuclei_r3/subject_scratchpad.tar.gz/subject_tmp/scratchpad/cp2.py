import numpy as np,tifffile as t,sys
from cellpose import models
im=t.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(im,[1,99.5]);x=np.clip((im-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
l,_,_=m.eval(x,diameter=23,flow_threshold=0.6,cellprob_threshold=-1.5)
t.imwrite(sys.argv[1]+'/cp23b.tif',l.astype(np.int32));print(l.max())
