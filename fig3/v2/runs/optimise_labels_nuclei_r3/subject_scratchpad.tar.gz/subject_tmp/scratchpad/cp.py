import numpy as np,tifffile as t,time
from cellpose import models
im=t.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(im,[1,99.5]);x=np.clip((im-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
s=time.time()
for d in [23]:
    l,_,_=m.eval(x,diameter=d,flow_threshold=0.4,cellprob_threshold=0.0)
    print(d,l.max(),time.time()-s)
    t.imwrite(f'{__import__("sys").argv[1]}/cp{d}.tif',l.astype(np.int32))
