import tifffile as t,numpy as np,time,sys
from cellpose import models
a=t.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(a,[1,99.8]);x=np.clip((a-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
for d in [None,23]:
    t0=time.time()
    r=m.eval(x,diameter=d,flow_threshold=0.4,cellprob_threshold=0.0,batch_size=4)[0]
    print(d,r.max(),time.time()-t0,flush=True)
    t.imwrite(f'{sys.argv[1]}/cp_{d}.tif',r.astype(np.int32))
