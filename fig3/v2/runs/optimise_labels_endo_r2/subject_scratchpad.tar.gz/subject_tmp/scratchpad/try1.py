import tifffile as t,numpy as np,time,sys
from cellpose import models
a=t.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(a,[1,99]);x=np.clip((a-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
print(m.pretrained_model)
t0=time.time()
for d in [None]:
    l,f,s=m.eval(x,diameter=d,flow_threshold=0.4,cellprob_threshold=0.0,normalize=False)
    print(d,l.max(),time.time()-t0)
    np.save('%s/l_%s.npy'%(sys.argv[1],d),l)
