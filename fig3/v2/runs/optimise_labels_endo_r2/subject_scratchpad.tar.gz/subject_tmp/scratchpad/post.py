import sys,warnings;warnings.filterwarnings('ignore');sys.path.insert(0,'/tmp/claude-0/-home-user-sessions-v2-v004/9d233c29-4670-401f-8559-bb1d10e34fa7/scratchpad')
import numpy as np,tifffile as t
from scipy import ndimage as ndi
from skimage import measure,morphology,segmentation
from ev import report
S='/tmp/claude-0/-home-user-sessions-v2-v004/9d233c29-4670-401f-8559-bb1d10e34fa7/scratchpad/'
x=t.imread(S+'x.tif');gt=t.imread('annotation.tif')
roi=ndi.binary_fill_holes(morphology.binary_closing(gt>0,morphology.disk(25)))
for name in ['l_0.5_0.4_0','l_0.4_0.8_-1','l_0.5_0.4_-1']:
  pr=t.imread(S+name+'.tif')
  for sd,amax in [(None,0),(1.2,1500),(1.0,1800),(1.5,2000)]:
    p=pr.copy()
    if sd:
        for r in measure.regionprops(p,intensity_image=x):
            if r.area<amax and r.intensity_std>sd: p[p==r.label]=0
    for ex in [0,3,6]:
        q=segmentation.expand_labels(p,ex) if ex else p
        print(name,sd,amax,ex,end=' ');report(gt,q,roi)
