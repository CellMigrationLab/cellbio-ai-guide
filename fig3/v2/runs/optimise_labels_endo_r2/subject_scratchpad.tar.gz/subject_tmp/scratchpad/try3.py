import tifffile as t,numpy as np,sys
sys.path.insert(0,sys.argv[1])
from ev import f1
from scipy import ndimage as ndi
from cellpose import models
gt=t.imread('annotation.tif');a=t.imread('image.tif').astype(np.float32)
ff=a-ndi.gaussian_filter(a,40);lo,hi=np.percentile(ff,[1,99]);x=np.clip((ff-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
for d,ft,cp in [(70,0.4,-1.0),(70,0.4,1.0),(70,0.8,0.0),(90,0.4,0.0),(60,0.4,0.0)]:
    l,_,_=m.eval(x,diameter=d,flow_threshold=ft,cellprob_threshold=cp,normalize=False)
    print(d,ft,cp,l.max(),f1(gt,l)[3],flush=True);np.save('%s/s_%d_%s_%s.npy'%(sys.argv[1],d,ft,cp),l)
