import sys,warnings;warnings.filterwarnings('ignore');sys.path.insert(0,'/tmp/claude-0/-home-user-sessions-v2-v004/9d233c29-4670-401f-8559-bb1d10e34fa7/scratchpad')
import numpy as np,tifffile as t
from skimage import measure
from ev import match
S='/tmp/claude-0/-home-user-sessions-v2-v004/9d233c29-4670-401f-8559-bb1d10e34fa7/scratchpad/'
x=t.imread(S+'x.tif');gt=t.imread('annotation.tif');pr=t.imread(S+'l_0.5_0.4_0.tif')
mt={p for g,p,_ in match(gt,pr)}
# fraction of pred inside gt
rows=[]
for r in measure.regionprops(pr,intensity_image=x):
    sl=r.slice;m=r.image
    ing=(gt[sl][m]>0).mean()
    rows.append((r.label,r.label in mt,r.area,r.solidity,r.eccentricity,r.intensity_std,ing,r.intensity_max,r.intensity_min))
a=np.array(rows,float)
for name,k in [('area',2),('solid',3),('ecc',4),('std',5),('ingt',6),('max',7),('min',8)]:
    for lab,sel in [('match',a[:,1]==1),('unmatched',(a[:,1]==0)&(a[:,6]>.5)),('outsideGT',a[:,6]<=.5)]:
        print(name,lab,sel.sum(),np.round(np.percentile(a[sel,k],[10,50,90]),2))
