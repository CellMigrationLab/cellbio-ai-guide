import tifffile as t,numpy as np,time,sys
sys.path.insert(0,sys.argv[1])
from ev import f1
from scipy import ndimage as ndi
from skimage import exposure
from cellpose import models
gt=t.imread('annotation.tif')
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,40);ff=a-bg
sd=np.sqrt(ndi.gaussian_filter(ff**2,40))
def norm(z):
    lo,hi=np.percentile(z,[1,99]);return np.clip((z-lo)/(hi-lo),0,1)
inputs={'raw':norm(a),'flat':norm(ff),'flatsd':norm(ff/sd)}
m=models.CellposeModel(gpu=False)
for k,x in inputs.items():
  for d in [50,70]:
    t0=time.time()
    l,_,_=m.eval(x,diameter=d,flow_threshold=0.4,cellprob_threshold=0.0,normalize=False)
    print(k,d,l.max(),f1(gt,l)[3],round(time.time()-t0),flush=True)
    np.save('%s/l_%s_%d.npy'%(sys.argv[1],k,d),l)
