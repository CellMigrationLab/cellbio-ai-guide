import sys;sys.path.insert(0,sys.argv[0].rsplit('/',1)[0])
import numpy as np,tifffile as t,time
from scipy import ndimage as ndi
from skimage import morphology
from cellpose import models
from ev import report
im=t.imread('image.tif').astype(np.float32);gt=t.imread('annotation.tif')
roi=ndi.binary_fill_holes(morphology.binary_closing(gt>0,morphology.disk(25)))
bg=ndi.gaussian_filter(im,40);x=im-bg
sd=np.sqrt(ndi.gaussian_filter(x**2,40));x=x/sd
m=models.CellposeModel(gpu=False)
for diam,scale in [(None,1.0),(None,0.5)]:
    xx=x if scale==1 else ndi.zoom(x,scale,order=1)
    t0=time.time()
    lab,fl,st=m.eval(xx,diameter=diam,flow_threshold=0.4,cellprob_threshold=0.0)[:3]
    if scale!=1: lab=ndi.zoom(lab,1/scale,order=0)[:im.shape[0],:im.shape[1]]
    print(scale,time.time()-t0);report(gt,lab,roi)
    t.imwrite(f'{sys.argv[0].rsplit("/",1)[0]}/b_{scale}.tif',lab.astype(np.int32))
