import numpy as np, tifffile as t
from skimage import measure, segmentation, io
def match(gt,pr,thr=0.5):
    gi=np.unique(gt)[1:];pi=np.unique(pr)[1:]
    m=(gt>0)&(pr>0)
    pairs,c=np.unique(np.stack([gt[m],pr[m]]),axis=1,return_counts=True)
    ga=dict(zip(*np.unique(gt,return_counts=True)));pa=dict(zip(*np.unique(pr,return_counts=True)))
    out=[]
    for (g,p),i in zip(pairs.T,c):
        iou=i/(ga[g]+pa[p]-i)
        if iou>=thr: out.append((g,p,iou))
    return out
def report(gt,pr,roi=None,px=0.65):
    if roi is not None:
        pr=pr.copy();
        ids=np.unique(pr)[1:]
        for r in measure.regionprops(pr):
            cy,cx=map(int,r.centroid)
            if not roi[cy,cx]: pr[pr==r.label]=0
    mt=match(gt,pr);tp=len(mt);ng=len(np.unique(gt))-1;npr=len(np.unique(pr))-1
    f1=2*tp/(ng+npr)
    gp={r.label:r for r in measure.regionprops(gt)};pp={r.label:r for r in measure.regionprops(pr)}
    ae=[abs(pp[p].area-gp[g].area)/gp[g].area for g,p,_ in mt]
    ar=[pp[p].major_axis_length/pp[p].minor_axis_length-gp[g].major_axis_length/gp[g].minor_axis_length for g,p,_ in mt]
    ga=np.array([r.area for r in gp.values()])*px*px;pa=np.array([r.area for r in pp.values()])*px*px
    gar=np.array([r.major_axis_length/max(r.minor_axis_length,1e-3) for r in gp.values()]);par=np.array([r.major_axis_length/max(r.minor_axis_length,1e-3) for r in pp.values()])
    print(f'GT {ng} pred {npr} TP@.5 {tp} F1 {f1:.3f} | matched medianAbsAreaErr {np.median(ae):.2f} ARdiff med {np.median(ar):+.2f} | median area gt {np.median(ga):.0f} pr {np.median(pa):.0f} | median AR gt {np.median(gar):.2f} pr {np.median(par):.2f}')
    return f1
