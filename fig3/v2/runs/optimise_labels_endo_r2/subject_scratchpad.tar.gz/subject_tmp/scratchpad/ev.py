import tifffile as t,numpy as np,sys
from skimage import measure,segmentation,io
def f1(gt,pr,thr=0.5):
    ng,npd=gt.max()+1,pr.max()+1
    h=np.histogram2d(gt.ravel(),pr.ravel(),bins=(ng,npd),range=((0,ng),(0,npd)))[0]
    ag=h.sum(1);ap=h.sum(0);iou=h/(ag[:,None]+ap[None,:]-h+1e-9)
    iou=iou[1:,1:];tp=(iou>thr).sum();ng_=(ag[1:]>0).sum();np_=(ap[1:]>0).sum()
    return tp,ng_,np_,2*tp/(ng_+np_)
def stats(l):
    r=measure.regionprops(l);return np.array([x.area*0.65**2 for x in r]),np.array([x.major_axis_length/max(x.minor_axis_length,1e-9) for x in r])
if __name__=='__main__':
    gt=t.imread('annotation.tif');pr=np.load(sys.argv[1]) if sys.argv[1].endswith('npy') else t.imread(sys.argv[1])
    print([f1(gt,pr,k) for k in (0.5,0.7)]);
    for n,l in(('gt',gt),('pr',pr)):
        a,e=stats(l);print(n,len(a),np.percentile(a,[10,50,90]).round(),np.percentile(e,[10,50,90]).round(2))
    a=t.imread('image.tif').astype(float);lo,hi=np.percentile(a,[.5,99.5]);g=np.clip((a-lo)/(hi-lo),0,1)
    o=segmentation.mark_boundaries(np.dstack([g]*3),pr,color=(1,0,0));o=segmentation.mark_boundaries(o,gt,color=(0,1,0))
    io.imsave(sys.argv[2],(o*255).astype(np.uint8))
