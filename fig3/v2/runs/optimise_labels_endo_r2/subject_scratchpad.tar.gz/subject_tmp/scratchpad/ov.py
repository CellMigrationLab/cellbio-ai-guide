import sys,numpy as np,tifffile as t
from skimage import segmentation,io
im=t.imread('image.tif').astype(float);l=t.imread(sys.argv[1])
n=np.clip((im-np.percentile(im,.5))/(np.percentile(im,99.5)-np.percentile(im,.5)),0,1)
n=(n-n.min())
from scipy import ndimage as ndi
x=im-ndi.gaussian_filter(im,40);n=np.clip(x/ (6*x.std())+0.5,0,1)
io.imsave(sys.argv[2],(segmentation.mark_boundaries(np.dstack([n]*3),l,color=(1,0,0))*255).astype('uint8'))
