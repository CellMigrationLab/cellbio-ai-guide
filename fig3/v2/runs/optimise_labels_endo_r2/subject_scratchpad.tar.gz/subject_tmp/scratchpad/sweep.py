import sys,warnings;warnings.filterwarnings('ignore');sys.path.insert(0,'/tmp/claude-0/-home-user-sessions-v2-v004/9d233c29-4670-401f-8559-bb1d10e34fa7/scratchpad')
import numpy as np,tifffile as t,time
from scipy import ndimage as ndi
from skimage import morphology,transform
from cellpose import models
from ev import report
S='/tmp/claude-0/-home-user-sessions-v2-v004/9d233c29-4670-401f-8559-bb1d10e34fa7/scratchpad/'
im=t.imread('image.tif').astype(np.float32);gt=t.imread('annotation.tif')
roi=ndi.binary_fill_holes(morphology.binary_closing(gt>0,morphology.disk(25)))
def prep(im,k=4,msz=15):
    sm=transform.downscale_local_mean(im,(k,k))
    bg=ndi.median_filter(sm,size=msz,mode='reflect')
    bg=transform.resize(bg,im.shape,order=1)
    x=im-bg
    sd=np.sqrt(ndi.gaussian_filter(x**2,40));return x/sd
x=prep(im);t.imwrite(S+'x.tif',x)
m=models.CellposeModel(gpu=False)
for scale in [0.4,0.5,0.65]:
  xx=transform.rescale(x,scale,order=1,anti_aliasing=True)
  for fl,cp in [(0.4,0),(0.4,-1),(0.8,-1)]:
    lab=m.eval(xx.astype(np.float32),flow_threshold=fl,cellprob_threshold=cp)[0]
    lab=transform.resize(lab,im.shape,order=0,preserve_range=True,anti_aliasing=False).astype(np.int32)
    print(scale,fl,cp,end=' ');report(gt,lab,roi)
    t.imwrite(S+f'l_{scale}_{fl}_{cp}.tif',lab)
