import sys; sys.path.insert(0,'.')
import pipeline as p, numpy as np
im=p.load_image('image.tif'); n=p.flatten_and_normalise(im); np.save(sys.argv[1]+'/norm.npy',n)
m=p.run_cellpose(n); np.save(sys.argv[1]+'/raw.npy',m)
