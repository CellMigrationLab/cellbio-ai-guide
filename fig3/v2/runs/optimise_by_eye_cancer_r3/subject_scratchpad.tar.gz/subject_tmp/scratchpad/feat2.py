import numpy as np, tifffile, sys
from scipy import ndimage as ndi
from skimage import measure, segmentation
from PIL import Image
S='/tmp/claude-0/-home-user-sessions-v2-v016/e3c4d99b-9516-4da5-a23d-a7434f978108/scratchpad'
im=tifffile.imread('image.tif').astype(np.float32); m=np.load(S+'/raw.npy')
g=ndi.gaussian_gradient_magnitude(im,1.5)
loc=ndi.median_filter(g[::4,::4],size=25); loc=np.kron(loc,np.ones((4,4)))[:im.shape[0],:im.shape[1]]
ratio=g/np.maximum(loc,1)
bd=segmentation.find_boundaries(m,mode='inner')
vals={}
for r in measure.regionprops(m):
    mk=(m==r.label)&bd
    vals[r.label]=(np.mean(ratio[mk]), r.area*.65**2, r.solidity)
v=np.array([x[0] for x in vals.values()]);print(np.percentile(v,[5,25,50,75,95]));print(np.histogram(v,bins=12))
thr=float(sys.argv[1])
good=np.zeros_like(m)
for k,x in vals.items():
    if x[0]>thr: good[m==k]=k
a=im;lo,hi=np.percentile(a,[.5,99.5]);b=np.clip((a-lo)/(hi-lo),0,1);rgb=np.dstack([b]*3)
rgb[segmentation.find_boundaries(good,mode='inner')]=[1,0,0]
rgb[segmentation.find_boundaries(np.where(good==0,m,0),mode='inner')]=[0,.6,1]
Image.fromarray((rgb*255).astype('uint8')).save(S+'/f2.png')
