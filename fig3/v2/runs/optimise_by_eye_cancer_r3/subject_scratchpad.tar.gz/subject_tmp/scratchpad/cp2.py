import sys;sys.path.insert(0,'.')
import pipeline as p,numpy as np
from cellpose import models
S=sys.argv[1]; n=np.load(S+'/norm.npy')
mod=models.CellposeModel(gpu=False,pretrained_model='cpsam')
m,_,_=mod.eval(n,diameter=30.,normalize=True,flow_threshold=0.4,cellprob_threshold=-2.0,min_size=int(100/.4225))
np.save(S+'/raw_m2.npy',m.astype(np.int32))
