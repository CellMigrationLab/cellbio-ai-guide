import sys; sys.path.insert(0,'/home/user/sessions_v2/v016')
import numpy as np,tifffile,pipeline as p
from scipy import ndimage as ndi
from skimage import measure,morphology,io,segmentation
img=p.read_image('image.tif'); f=p.preprocess(img)
lab=tifffile.imread(sys.argv[1])
g=ndi.gaussian_gradient_magnitude(img.astype(float),1.5)
sd=ndi.generic_filter if False else None
rows=[]
for r in measure.regionprops(lab):
    m=lab==r.label
    rim=m&~ndi.binary_erosion(m,iterations=3)
    rows.append((r.label,r.area,r.solidity,r.eccentricity,g[rim].mean(),img[m].std(),f[m].mean()))
a=np.array(rows)
np.save(sys.argv[2],a)
np.set_printoptions(suppress=True,precision=2,linewidth=150)
print(len(a));
for q in (10,25,50,75,90): print(q,np.percentile(a,q,axis=0)[1:])
