import numpy as np, tifffile
from scipy import ndimage as ndi
from skimage import measure, io, segmentation
S='/tmp/claude-0/-home-user-sessions-v2-v016/e3c4d99b-9516-4da5-a23d-a7434f978108/scratchpad'
n=np.load(S+'/norm.npy'); m=np.load(S+'/raw.npy')
rows=[]
for r in measure.regionprops(m):
    msk=m==r.label
    d_in=ndi.distance_transform_edt(msk); d_out=ndi.distance_transform_edt(~msk)
    rim=msk&(d_in<=3); halo=(~msk)&(d_out<=4)&(m==0)
    if halo.sum()<10: continue
    c=n[halo].mean()-n[rim].mean()
    # gradient magnitude at boundary
    rows.append((r.label,r.area*.65**2,r.solidity,c,n[msk].std(),r.centroid))
import pickle;pickle.dump(rows,open(S+'/feat.pkl','wb'))
c=np.array([x[3] for x in rows]);print(np.percentile(c,[5,25,50,75,95]))
# overlay with contrast values
a=tifffile.imread('image.tif').astype(float);lo,hi=np.percentile(a,[.5,99.5]);b=np.clip((a-lo)/(hi-lo),0,1)
rgb=np.dstack([b]*3)
from PIL import Image,ImageDraw
good=np.zeros_like(m)
for x in rows:
    if x[3]>float(__import__('sys').argv[1]): good[m==x[0]]=x[0]
bd=segmentation.find_boundaries(good,mode='inner');rgb[bd]=[1,0,0]
bd=segmentation.find_boundaries(np.where(good==0,m,0),mode='inner');rgb[bd]=[0,.6,1]
im=Image.fromarray((rgb*255).astype('uint8'))
im.save(S+'/f.png')
