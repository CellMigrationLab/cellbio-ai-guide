import sys,tifffile,numpy as np
from skimage import io,segmentation
a=tifffile.imread('/home/user/sessions_v2/v016/image.tif').astype(float)
lo,hi=np.percentile(a,[0.5,99.8]);b=np.clip((a-lo)/(hi-lo),0,1)
l=tifffile.imread(sys.argv[1])
o=segmentation.mark_boundaries(np.dstack([b]*3),l,color=(1,0,0),mode='inner')
io.imsave(sys.argv[2],(o*255).astype(np.uint8))
