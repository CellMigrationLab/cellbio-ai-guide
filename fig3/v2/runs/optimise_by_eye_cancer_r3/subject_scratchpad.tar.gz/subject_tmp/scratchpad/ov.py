import sys,tifffile,numpy as np
from skimage import io,segmentation
a=tifffile.imread('image.tif').astype(float);l=tifffile.imread(sys.argv[1])
lo,hi=np.percentile(a,[0.5,99.5]);b=np.clip((a-lo)/(hi-lo),0,1)
r=np.dstack([b]*3);bd=segmentation.find_boundaries(l,mode='inner');r[bd]=[1,0,0]
from skimage.transform import resize
io.imsave(sys.argv[2],(np.kron(r,np.ones((1,1,1)))*255).astype('uint8'))
