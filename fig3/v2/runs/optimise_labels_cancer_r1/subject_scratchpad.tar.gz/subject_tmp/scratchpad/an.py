import sys; sys.path.insert(0,'/home/user/sessions_v2/v009')
import numpy as np, tifffile, pandas as pd
from skimage import measure, morphology
from scipy import ndimage as ndi
import pipeline as P, evaluate as E
S='/tmp/claude-0/-home-user-sessions-v2-v009/a37ba08f-34bf-4c18-a62a-d317d19ab9bb/scratchpad/'
img=P.load_image('image.tif'); norm=P.flatfield_normalise(img,40)
raw=tifffile.imread(S+'raw_masks.tif'); gt=tifffile.imread('annotation.tif')
m,_,_=E.match(gt,raw); pos={b for _,b,_ in m}
loc=ndi.generic_filter if False else None
sd=np.sqrt(np.maximum(ndi.uniform_filter(norm**2,5)-ndi.uniform_filter(norm,5)**2,0))
rows=[]
for r in measure.regionprops(raw,intensity_image=norm):
    mk=raw==r.label
    ring=ndi.binary_dilation(mk,iterations=4)&~ndi.binary_dilation(mk,iterations=1)&(raw==0)
    rows.append(dict(l=r.label,pos=r.label in pos,area=r.area*.4225,sol=r.solidity,ecc=r.eccentricity,
      mean=r.mean_intensity,std=norm[mk].std(),tex=sd[mk].mean(),mn=norm[mk].min(),
      ring=norm[ring].mean() if ring.any() else np.nan,dark=np.percentile(norm[mk],5)))
d=pd.DataFrame(rows); d['contrast']=d['mean']-d['ring']
pd.set_option('display.width',200)
print(d.groupby('pos').describe().T.to_string())
d.to_pickle(S+'feat.pkl')
