import sys; sys.path.insert(0,'/home/user/sessions_v2/v009')
import numpy as np, tifffile, pandas as pd
from skimage import measure
import pipeline as P
from scipy import ndimage as ndi
img=P.load_image('image.tif'); norm=P.flatfield_normalise(img,40)
raw=P.run_cellpose(norm,P.PARAMS)
tifffile.imwrite('/tmp/claude-0/-home-user-sessions-v2-v009/a37ba08f-34bf-4c18-a62a-d317d19ab9bb/scratchpad/raw_masks.tif',raw)
