import sys; sys.path.insert(0,'/home/user/sessions_v2/v062')
import pipeline as p, numpy as np
p.FLOW_THRESHOLD=0.0; p.CELLPROB_THRESHOLD=-1.0
np.save('/tmp/claude-0/-home-user-sessions-v2-v062/cdc73e0a-2490-4abe-ae09-a57276e342b6/scratchpad/raw_masks_b.npy',p.run_cellpose(np.load('/tmp/claude-0/-home-user-sessions-v2-v062/cdc73e0a-2490-4abe-ae09-a57276e342b6/scratchpad/norm.npy')))
