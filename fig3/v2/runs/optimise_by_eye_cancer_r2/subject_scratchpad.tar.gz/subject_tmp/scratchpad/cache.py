import sys; sys.path.insert(0,'/home/user/sessions_v2/v062')
import pipeline as p, numpy as np
im=p.load_image('image.tif'); n=p.normalise_by_segment(im,p.find_seams(im))
np.save('/tmp/claude-0/-home-user-sessions-v2-v062/cdc73e0a-2490-4abe-ae09-a57276e342b6/scratchpad/norm.npy',n); np.save('/tmp/claude-0/-home-user-sessions-v2-v062/cdc73e0a-2490-4abe-ae09-a57276e342b6/scratchpad/raw_masks.npy',p.run_cellpose(n))
