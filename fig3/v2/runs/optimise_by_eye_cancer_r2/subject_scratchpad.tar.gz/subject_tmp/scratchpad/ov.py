import sys,tifffile,numpy as np
from skimage import io,segmentation
a=tifffile.imread('image.tif').astype(float);l=tifffile.imread(sys.argv[1])
lo,hi=np.percentile(a,[.5,99.5]);b=np.clip((a-lo)/(hi-lo),0,1)
# per-half stretch for visibility
for s in (slice(0,512),slice(512,1024)):
    x=a[:,s];lo,hi=np.percentile(x,[.5,99.5]);b[:,s]=np.clip((x-lo)/(hi-lo),0,1)
o=segmentation.mark_boundaries(np.dstack([b]*3),l,color=(1,0,0),mode='inner')
io.imsave(sys.argv[2],(o*255).astype(np.uint8))
