import tifffile as t,numpy as np,sys
from scipy import ndimage as ndi
from skimage import morphology as mo,measure,io,segmentation
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,40); sd=np.sqrt(ndi.gaussian_filter((a-bg)**2,40))
f=(a-bg)/sd
thr=float(sys.argv[1])
hi=ndi.gaussian_filter(f,1)>thr
hi=mo.binary_closing(hi,mo.disk(2))
filled=ndi.binary_fill_holes(hi)
filled=mo.binary_opening(filled,mo.disk(4))
lab=measure.label(filled)
out=np.zeros_like(lab)
k=0
for r in measure.regionprops(lab):
    d=r.equivalent_diameter*0.65
    circ=4*np.pi*r.area/max(r.perimeter,1)**2
    if 8<d<30 and r.solidity>0.85: k+=1;out[lab==r.label]=k
print(k)
np.save('%s/cancer.npy'%S,out)
v=np.clip((f+2.5)/6,0,1)
o=segmentation.mark_boundaries(np.dstack([v]*3),out,color=(1,0,0))
io.imsave('%s/cancer.png'%S,(o*255).astype('uint8'))
