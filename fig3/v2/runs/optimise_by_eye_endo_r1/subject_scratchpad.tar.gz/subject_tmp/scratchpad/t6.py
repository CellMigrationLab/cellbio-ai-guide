import sys; sys.path.insert(0,'/home/user/sessions_v2/v015')
import numpy as np,tifffile as t
from scipy import ndimage as ndi
from skimage import measure,segmentation,io
import pipeline as p
img=p.read_image('image.tif'); f=p.flatten(img)
raw=t.imread('out_labels_raw_cellpose.tif').astype(int)
# edge strength: gradient magnitude of lightly smoothed f, 90th pct in label
g=ndi.gaussian_gradient_magnitude(f,1.5)
S='/tmp/claude-0/-home-user-sessions-v2-v015/29c47e69-5341-4386-a7cc-1b45cceede0f/scratchpad'
rows=[]
for r in measure.regionprops(raw):
    m=raw[r.slice]==r.label
    ring=m&~ndi.binary_erosion(m,iterations=3)
    rows.append((r.label,r.area*.4225,r.solidity,r.major_axis_length/max(r.minor_axis_length,1e-6),
                 np.percentile(f[r.slice][m],98),np.percentile(g[r.slice][m],90),f[r.slice][m].std()))
R=np.array(rows);np.save(S+'/R.npy',R)
thr=float(sys.argv[1]); col=int(sys.argv[2])
can=R[(R[:,col]>thr)&(R[:,1]<900),0].astype(int)
print(len(can))
lo,hi=np.percentile(img,[.5,99.5])
rgb=np.dstack([np.clip((img-lo)/(hi-lo),0,1)]*3)
b=segmentation.find_boundaries(raw,mode='inner');isc=np.isin(raw,can)
rgb[b&~isc]=(0,1,0);rgb[b&isc]=(1,0,1)
io.imsave(S+'/cls2.png',(rgb*255).astype('uint8'))
