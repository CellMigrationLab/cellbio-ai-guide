import tifffile as t,numpy as np
from scipy import ndimage as ndi
from skimage import measure,io,segmentation,transform,draw
S='/tmp/claude-0/-home-user-sessions-v2-v015/29c47e69-5341-4386-a7cc-1b45cceede0f/scratchpad'
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,40); sd=np.sqrt(ndi.gaussian_filter((a-bg)**2,40))
f=(a-bg)/sd
l=np.load(S+'/r05.npy')
fs=transform.resize(f,l.shape,order=1,anti_aliasing=True)
rows=[]
for r in measure.regionprops(l,intensity_image=fs):
    m=l[r.slice]==r.label
    v=fs[r.slice][m]
    rows.append((r.label,r.area*1.69,r.solidity,np.percentile(v,98),v.std(),r.centroid))
rows=np.array([(x[0],x[1],x[2],x[3],x[4]) for x in rows])
np.save(S+'/feat.npy',rows)
# annotate image with label ids
v=np.clip((fs+2.5)/6,0,1)
big=transform.resize(v,(1024,1024),order=1)
L=transform.resize(l,(1024,1024),order=0,preserve_range=True,anti_aliasing=False).astype(int)
o=segmentation.mark_boundaries(np.dstack([big]*3),L,color=(1,0,0))
io.imsave(S+'/r05big.png',(o*255).astype('uint8'))
for q in (50,80,90,95,98): print(q,np.percentile(rows[:,3],q).round(2),np.percentile(rows[:,4],q).round(2))
