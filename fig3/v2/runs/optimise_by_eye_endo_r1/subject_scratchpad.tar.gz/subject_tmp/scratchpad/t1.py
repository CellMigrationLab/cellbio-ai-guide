import tifffile as t,numpy as np,time,sys
from scipy import ndimage as ndi
from skimage import transform,io,segmentation,exposure
from cellpose import models
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,40); sd=np.sqrt(ndi.gaussian_filter((a-bg)**2,40))
f=(a-bg)/sd
scale=float(sys.argv[1])
s=transform.rescale(f,scale,order=1,anti_aliasing=True)
m=models.CellposeModel(gpu=False)
t0=time.time()
lab,_,_=m.eval(s,diameter=None,flow_threshold=0.4,cellprob_threshold=float(sys.argv[2]),niter=None,batch_size=1,tile_overlap=0.1)
print(time.time()-t0,lab.max())
np.save(f'{sys.argv[3]}.npy',lab)
v=np.clip((s+2.5)/6,0,1)
o=segmentation.mark_boundaries(np.dstack([v]*3),lab,color=(1,0,0))
io.imsave(f'{sys.argv[3]}.png',(o*255).astype('uint8'))
