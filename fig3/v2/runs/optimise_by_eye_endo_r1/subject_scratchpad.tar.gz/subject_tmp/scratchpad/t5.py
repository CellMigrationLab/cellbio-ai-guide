import tifffile as t,numpy as np,sys
from scipy import ndimage as ndi
from skimage import feature,transform,io,draw
S='/tmp/claude-0/-home-user-sessions-v2-v015/29c47e69-5341-4386-a7cc-1b45cceede0f/scratchpad'
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,40); sd=np.sqrt(ndi.gaussian_filter((a-bg)**2,40))
f=(a-bg)/sd
fh=ndi.gaussian_filter(f,1.5)
# bright halo ring detection: edges of strongly bright pixels
bright=fh>float(sys.argv[1])
edges=feature.canny(f,sigma=2,high_threshold=float(sys.argv[2])*1.0,low_threshold=0.5,mask=ndi.binary_dilation(bright,iterations=3))
radii=np.arange(9,20)
h=transform.hough_circle(edges,radii)
acc,cx,cy,r=transform.hough_circle_peaks(h,radii,min_xdistance=14,min_ydistance=14,threshold=float(sys.argv[3])*0.01*1,total_num_peaks=400)
keep=acc>float(sys.argv[3])
print(keep.sum(),np.sort(acc)[::-1][:5],np.percentile(acc,[10,50,90]))
v=np.dstack([np.clip((f+2.5)/6,0,1)]*3)
for c,y,x,rr,k in zip(cx,cy,cx*0,r,keep): pass
for ac,x,y,rr in zip(acc,cx,cy,r):
    if ac>float(sys.argv[3]):
        i,j=draw.circle_perimeter(y,x,rr,shape=v.shape[:2]);v[i,j]=(1,0,0)
io.imsave(S+'/hough.png',(v*255).astype('uint8'))
