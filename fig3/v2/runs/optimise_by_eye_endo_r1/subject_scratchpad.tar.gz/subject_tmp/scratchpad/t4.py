import numpy as np,tifffile as t
from skimage import io,segmentation,transform
S='/tmp/claude-0/-home-user-sessions-v2-v015/29c47e69-5341-4386-a7cc-1b45cceede0f/scratchpad'
import sys
thr=float(sys.argv[1])
F=np.load(S+'/feat.npy');l=np.load(S+'/r05.npy')
can=F[(F[:,3]>thr),0].astype(int)
print(len(can),len(F))
a=t.imread('image.tif').astype(float)
lo,hi=np.percentile(a,[.5,99.5]);
L=transform.resize(l,(1022,1024),order=0,preserve_range=True,anti_aliasing=False).astype(int)
isc=np.isin(L,can)
img=np.dstack([np.clip((a-lo)/(hi-lo),0,1)]*3)
b=segmentation.find_boundaries(L,mode='inner')
img[b&~isc]=(0,1,0); img[b&isc]=(1,0,1)
io.imsave(S+'/cls.png',(img*255).astype('uint8'))
