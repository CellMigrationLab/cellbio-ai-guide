import sys,numpy as np,tifffile
sys.path.insert(0,'/home/user/sessions_v2/v017')
import pipeline as p
import skimage.io as io
from skimage.segmentation import find_boundaries
S='/tmp/claude-0/-home-user-sessions-v2-v017/78055e03-1956-4533-979c-268956f1b8ca/scratchpad'
img=p.load_image('/home/user/sessions_v2/v017/image.tif');raw=np.load(S+'/m_raw.npy')
final,table,refined,feats=p.build_outputs(img,raw)
print(len(table),feats.rejected.value_counts().to_dict());print(table.describe().round(2))
a=img.astype(float);lo,hi=np.percentile(a,[1,99.8]);b=np.clip((a-lo)/(hi-lo),0,1)**0.6
rgb=np.dstack([b]*3)
rej=np.isin(refined,feats.label[feats.rejected!=''])
rgb[find_boundaries(refined,mode='inner')&rej]=[0.2,0.6,1]
rgb[find_boundaries(final,mode='inner')]=[1,0.2,0.2]
io.imsave(S+'/ov2.png',(rgb*255).astype('uint8'))
