import tifffile,numpy as np,time
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(a,[1,99.5]); x=np.clip((a-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
t=time.time()
for name,img in [('raw',x),('log',np.log1p(a*1.0)/np.log1p(4095))]:
    l,_,_=m.eval(img,batch_size=4,normalize=True,flow_threshold=0.4,cellprob_threshold=0.0)
    np.save(f'{name}.npy',l) if False else np.save(f'{__import__("os").environ["S"]}/{name}.npy',l)
    print(name,l.max(),time.time()-t)
