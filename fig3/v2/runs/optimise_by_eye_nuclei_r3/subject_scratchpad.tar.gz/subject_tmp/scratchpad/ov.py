import sys,tifffile,numpy as np,skimage.io as io
from skimage.segmentation import find_boundaries
from skimage.measure import regionprops
a=tifffile.imread('image.tif').astype(float)
L=np.load(sys.argv[1])
lo,hi=np.percentile(a,[1,99.8]);b=np.clip((a-lo)/(hi-lo),0,1)**0.6
rgb=np.dstack([b]*3);bd=find_boundaries(L,mode='inner')
rgb[bd]=[1,0.2,0.2]
io.imsave(sys.argv[2],(rgb*255).astype('uint8'))
import pandas as pd
rp=regionprops(L,intensity_image=a)
d=pd.DataFrame([(r.label,r.area*.65**2,r.major_axis_length/max(r.minor_axis_length,1e-9),r.solidity,r.intensity_mean,r.intensity_max) for r in rp],columns='l area ar sol mean max'.split())
print(d.describe().round(2))
