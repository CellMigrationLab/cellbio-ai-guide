import tifffile,numpy as np,time
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(a,[1,99.5]);x=np.clip((a-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False,pretrained_model='cpsam')
t=time.time()
for d in (None,):
    r=m.eval(x,diameter=None,flow_threshold=0.4,cellprob_threshold=0.0,batch_size=4)
    print(d,r[0].max(),time.time()-t)
    np.save('/tmp/claude-0/-home-user-sessions-v2-v017/78055e03-1956-4533-979c-268956f1b8ca/scratchpad/m_raw.npy',r[0])
