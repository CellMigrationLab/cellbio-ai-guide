import tifffile,numpy as np,pandas as pd
from skimage.measure import regionprops
a=tifffile.imread('image.tif').astype(float);L=np.load('%s/m_raw.npy'%'/tmp/claude-0/-home-user-sessions-v2-v017/78055e03-1956-4533-979c-268956f1b8ca/scratchpad')
rp=regionprops(L,intensity_image=a)
d=pd.DataFrame([(r.label,r.centroid[1],r.area*.65**2,r.axis_major_length/r.axis_minor_length,r.intensity_mean,np.percentile(r.image_intensity[r.image],90) if 0 else r.intensity_max) for r in rp],columns='l x area ar mean max'.split())
d['rel']=d['mean']/d.groupby(d.x>512)['mean'].transform('median')
print(d.groupby(d.x>512)[['area','ar','mean']].median())
print(np.histogram(d.rel,bins=[0,.6,.8,1,1.2,1.5,2,2.5,3,5,10]))
print(np.histogram(d.area,bins=[0,40,60,80,100,120,160,200,300,500,2000]))
d.to_csv('/tmp/claude-0/-home-user-sessions-v2-v017/78055e03-1956-4533-979c-268956f1b8ca/scratchpad/f.csv')
