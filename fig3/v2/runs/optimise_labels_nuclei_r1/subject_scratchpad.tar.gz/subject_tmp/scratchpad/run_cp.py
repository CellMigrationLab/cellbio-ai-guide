S='/tmp/claude-0/-home-user-sessions-v2-v034/cca6f1f1-93ee-4f15-a086-da084a3b3d84/scratchpad'
import tifffile,numpy as np,time,sys
from cellpose import models
im=tifffile.imread('image.tif').astype(np.float32)
m=models.CellposeModel(gpu=False)
for name,scale in [('s1',1.0)]:
    x=im
    if scale!=1:
        from skimage.transform import rescale
        x=rescale(im,scale,order=1,preserve_range=True)
    t=time.time()
    lab,_,_=m.eval(x,diameter=None,normalize={'percentile':[1,99.5]},flow_threshold=0.4,cellprob_threshold=-1.0,niter=None)
    if scale!=1:
        from skimage.transform import resize
        lab=resize(lab,im.shape,order=0,preserve_range=True,anti_aliasing=False).astype(np.int32)
    print(name,lab.max(),time.time()-t)
    np.save(f'{S}/{name}.npy',lab)
