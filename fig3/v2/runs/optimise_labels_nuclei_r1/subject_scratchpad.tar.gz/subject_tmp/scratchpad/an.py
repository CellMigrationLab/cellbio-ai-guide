import tifffile,numpy as np,pandas as pd
from skimage.measure import regionprops_table
S='/tmp/claude-0/-home-user-sessions-v2-v034/cca6f1f1-93ee-4f15-a086-da084a3b3d84/scratchpad'
im=tifffile.imread('image.tif').astype(float); gt=tifffile.imread('annotation.tif'); p=np.load(S+'/s1.npy')
t=pd.DataFrame(regionprops_table(p,im,properties=['label','area','solidity','eccentricity','mean_intensity','axis_major_length','axis_minor_length']))
# match
ov=pd.crosstab(p.ravel(),gt.ravel()); 
best={};
for l in t.label:
    r=ov.loc[l]; r=r.drop(0,errors='ignore')
    if len(r) and r.max()>0:
        g=r.idxmax(); inter=r.max(); union=(p==l).sum()+(gt==g).sum()-inter
        best[l]=inter/union
    else: best[l]=0
t['iou']=t.label.map(best); t['endo']=t.iou>0.5
t['area_um']=t.area*0.65**2; t['ar']=t.axis_major_length/t.axis_minor_length
print(t.endo.sum(), len(t))
print(t.groupby('endo')[['area_um','solidity','ar','mean_intensity']].describe().T.to_string())
t.to_csv(S+'/t.csv')
