import numpy as np,tifffile,pandas as pd
from scipy import ndimage as ndi
from skimage.measure import regionprops, label as cc
from skimage.filters import gaussian
S='/tmp/claude-0/-home-user-sessions-v2-v034/cca6f1f1-93ee-4f15-a086-da084a3b3d84/scratchpad'
im=tifffile.imread('image.tif').astype(float); gt=tifffile.imread('annotation.tif'); p=np.load(S+'/s1.npy')
sm=gaussian(im,1,preserve_range=True)
def refine(p,frac):
    out=np.zeros_like(p)
    for r in regionprops(p):
        y0,x0,y1,x1=r.bbox; m=r.image
        pad=((0,0),(0,0))
        v=sm[y0:y1,x0:x1]
        core=ndi.binary_erosion(m,iterations=3) if m.sum()>60 else m
        hi=np.median(v[core]) if core.any() else np.median(v[m])
        lo=np.percentile(v,5)  # local background within bbox
        t=lo+frac*(hi-lo)
        k=m&(v>t)
        k=ndi.binary_fill_holes(k)
        l,n=ndi.label(k)
        if n==0: continue
        sizes=ndi.sum(k,l,range(1,n+1)); k=l==(1+sizes.argmax())
        out[y0:y1,x0:x1][k&(out[y0:y1,x0:x1]==0)]=r.label
    return out
def score(q):
    ids=np.unique(gt)[1:]; ious=[]
    ov=pd.crosstab(gt.ravel(),q.ravel())
    ga=ov.sum(1); qa=ov.sum(0)
    for g in ids:
        row=ov.loc[g].drop(0,errors='ignore')
        if len(row)==0 or row.max()==0: ious.append(0);continue
        l=row.idxmax(); i=row.max(); ious.append(i/(ga[g]+qa[l]-i))
    return np.array(ious)
if __name__=='__main__':
    for f in [None,0.3,0.4,0.5,0.6]:
        q=p if f is None else refine(p,f)
        s=score(q); print(f,(s>0.5).sum(),(s>0.7).sum(),np.median(s))
