import sys; sys.path.insert(0,'.')
import pipeline as P, numpy as np, tifffile
img=P.load_image('image.tif'); np.save(sys.argv[1], P.run_cellpose(P.normalise(img)))
