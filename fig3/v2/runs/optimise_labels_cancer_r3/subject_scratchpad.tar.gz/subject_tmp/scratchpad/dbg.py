import sys,tifffile,numpy as np
sys.path.insert(0,'/home/user/sessions_v2/v013')
import pipeline as P
S='/tmp/claude-0/-home-user-sessions-v2-v013/9f79c716-b21d-4dc3-b567-3711d2179109/scratchpad'
img=P.read_image('image.tif');ff=P.flatfield(img,50)
raw=P.run_cellpose(ff,P.PARAMS);tifffile.imwrite(S+'/raw2.tif',raw)
print(raw.max(),(raw>0).sum())
o=P.filter_objects(raw,ff,P.PARAMS);print(o.max())
