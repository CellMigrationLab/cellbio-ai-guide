import sys,numpy as np,tifffile,time
sys.path.insert(0,'/home/user/sessions_v2/v013')
import pipeline as P
S=sys.argv[1]
img=P.read_image('image.tif');ff=P.flatfield(img,50)
t=time.time()
for i in range(2):
    m=P.run_cellpose(ff,P.PARAMS);tifffile.imwrite(f'{S}/raw{i}.tif',m);print(i,m.max(),time.time()-t,flush=True)
