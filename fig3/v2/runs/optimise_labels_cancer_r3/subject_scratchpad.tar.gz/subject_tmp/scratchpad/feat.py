import numpy as np, tifffile, sys
sys.path.insert(0,'/home/user/sessions_v2/v013')
import pipeline as P
from skimage import measure, io, segmentation
from scipy import ndimage as ndi
img=P.read_image('image.tif'); ff=P.flatfield(img,50)
l=tifffile.imread(f'{sys.argv[1]}/l.tif'); g=tifffile.imread('annotation.tif')
rows=[]
sd=ndi.generic_filter(ff,np.std,size=5) if False else None
loc_std=np.sqrt(np.maximum(ndi.uniform_filter(ff**2,5)-ndi.uniform_filter(ff,5)**2,0))
for r in measure.regionprops(l,intensity_image=ff):
    m=l==r.label
    best=np.bincount(g[m]).copy(); best[0]=0
    tp = best.max()/ (r.area+ (g==best.argmax()).sum()-best.max())>=0.5 if best.max()>0 else False
    ring=ndi.binary_dilation(m,iterations=4)&~ndi.binary_dilation(m,iterations=1)&(l==0)
    rows.append((tp,r.area*.4225,r.solidity,r.eccentricity,r.intensity_mean-ff[ring].mean(),r.intensity_std,loc_std[m].mean(),ff[m].min()-ff[ring].mean(), np.percentile(ff[m],5)-ff[ring].mean(), np.percentile(ff[m],95)-ff[ring].mean()))
a=np.array(rows,float)
names='area solidity ecc dmean std locstd min p5 p95'.split()
for i,n in enumerate(names):
    print(n,'TP',np.percentile(a[a[:,0]==1,i+1],[10,50,90]).round(3),'FP',np.percentile(a[a[:,0]==0,i+1],[10,50,90]).round(3))
np.save(f'{sys.argv[1]}/feat.npy',a)
n=np.clip((ff-np.percentile(ff,.5))/(np.percentile(ff,99.5)-np.percentile(ff,.5)),0,1);rgb=np.dstack([n]*3)
rgb[segmentation.find_boundaries(l)&(l>0)]=[1,0,0]
rgb[segmentation.find_boundaries(g)]=[0,1,0]
io.imsave(f'{sys.argv[1]}/ov.png',(rgb*255).astype('uint8'))
