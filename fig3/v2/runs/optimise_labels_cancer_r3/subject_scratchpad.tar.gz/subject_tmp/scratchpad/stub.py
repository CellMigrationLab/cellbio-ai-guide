import sys,tifffile,runpy
sys.path.insert(0,'/home/user/sessions_v2/v013')
import pipeline as P
S='/tmp/claude-0/-home-user-sessions-v2-v013/9f79c716-b21d-4dc3-b567-3711d2179109/scratchpad'
raw=tifffile.imread(S+'/raw0.tif')
P.run_cellpose=lambda img,p: raw
P.main('image.tif',S+'/l4.tif',S+'/m4.csv')
