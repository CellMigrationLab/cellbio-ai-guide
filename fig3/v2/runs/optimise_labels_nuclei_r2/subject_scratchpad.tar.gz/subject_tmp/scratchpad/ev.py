import numpy as np
from skimage import measure
def match(gt,pr,thr=0.5):
    n=gt.max()+1;m=pr.max()+1
    full=np.bincount(gt.ravel().astype(np.int64)*m+pr.ravel(),minlength=n*m).reshape(n,m)
    ct=full[1:,1:];ga=full.sum(1)[1:,None];pa=full.sum(0)[None,1:]
    iou=ct/np.maximum(ga+pa-ct,1)
    pairs=[]
    gi,pi=np.where(iou>thr)
    return {g:(p,iou[g,p]) for g,p in zip(gi,pi)}  # iou>0.5 is unique
def report(gt,pr):
    gids=np.unique(gt[gt>0]);pids=np.unique(pr[pr>0])
    gt2=measure.label(gt>0,connectivity=1) if False else gt
    from skimage.segmentation import relabel_sequential
    g=relabel_sequential(gt)[0];p=relabel_sequential(pr)[0]
    mt=match(g,p)
    tp=len(mt);fp=p.max()-tp;fn=g.max()-tp
    rg=measure.regionprops(g);rp=measure.regionprops(p)
    ae=[];are=[];ious=[]
    for gi,(pi,i) in mt.items():
        a,b=rg[gi],rp[pi];ious.append(i)
        ae.append(b.area/a.area-1);are.append(b.axis_major_length/b.axis_minor_length/(a.axis_major_length/a.axis_minor_length)-1)
    ga=np.array([r.area for r in rg])*.4225;pa=np.array([r.area for r in rp])*.4225
    gar=np.mean([r.axis_major_length/r.axis_minor_length for r in rg]);par=np.mean([r.axis_major_length/r.axis_minor_length for r in rp])
    return dict(nGT=g.max(),nPred=p.max(),TP=tp,FP=fp,FN=fn,F1=round(2*tp/(2*tp+fp+fn),3),prec=round(tp/max(tp+fp,1),3),rec=round(tp/g.max(),3),
      medIoU=round(float(np.median(ious)),3),areaBias=round(float(np.median(ae)),3),arBias=round(float(np.median(are)),3),
      medAreaGT=round(float(np.median(ga)),1),medAreaPr=round(float(np.median(pa)),1),meanARgt=round(gar,3),meanARpr=round(par,3))
