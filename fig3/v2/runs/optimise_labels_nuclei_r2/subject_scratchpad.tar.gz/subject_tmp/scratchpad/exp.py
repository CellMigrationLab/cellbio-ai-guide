import sys,time,numpy as np,tifffile as t
from cellpose import models
S=sys.argv[1];name=sys.argv[2];cap=float(sys.argv[3]);d=float(sys.argv[4])
a=t.imread('image.tif').astype(np.float32)
m=models.CellposeModel(gpu=False)
hi=np.percentile(a,cap); lo=np.percentile(a,1)
x=np.clip((a-lo)/(hi-lo),0,1)
t0=time.time()
mk=m.eval(x,normalize=False,diameter=d,bsize=256)[0]
np.save(f'{S}/mk_{name}_{int(d)}.npy',mk);print(name,d,mk.max(),time.time()-t0,flush=True)
