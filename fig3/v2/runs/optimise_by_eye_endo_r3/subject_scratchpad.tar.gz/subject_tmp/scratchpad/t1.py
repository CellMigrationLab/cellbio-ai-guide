import tifffile as t,numpy as np,time
from scipy import ndimage as ndi
from skimage import transform,io,segmentation,exposure
from cellpose import models
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,40);d=a-bg
sd=np.sqrt(ndi.gaussian_filter(d**2,40));n=d/sd
lo,hi=np.percentile(n,[1,99]);n=np.clip((n-lo)/(hi-lo),0,1)
sc=0.5
small=transform.rescale(n,sc,order=1,anti_aliasing=True).astype(np.float32)
m=models.CellposeModel(gpu=False)
t0=time.time()
for ft,cp in ((0.4,0.0),):
    r=m.eval(small,diameter=None,flow_threshold=ft,cellprob_threshold=cp,batch_size=1)[0]
    print(ft,cp,r.max(),time.time()-t0)
lab=transform.resize(r,a.shape,order=0,preserve_range=True,anti_aliasing=False).astype(np.int32)
np.save('/tmp/lab.npy',lab)
b=segmentation.mark_boundaries(np.dstack([n]*3),lab,color=(1,0,0))
io.imsave('/tmp/claude-0/-home-user-sessions-v2-v012/f7c175c8-1a7a-4818-a48c-0446f438281d/scratchpad/ov1.png',(b*255).astype('uint8'))
