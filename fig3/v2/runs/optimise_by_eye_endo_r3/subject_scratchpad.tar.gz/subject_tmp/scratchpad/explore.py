import tifffile,numpy as np
from skimage import io,morphology as mo,measure,segmentation
from scipy import ndimage as ndi
a=tifffile.imread('image.tif').astype(np.float32)
d=a-ndi.gaussian_filter(a,50)
sd=np.sqrt(np.maximum(ndi.uniform_filter(d**2,7)-ndi.uniform_filter(d,7)**2,0))
print(np.percentile(sd,[50,75,90,95,99]),np.median(sd))
robust=np.median(np.abs(d-np.median(d)))*1.4826
print('mad',robust)
for t in (3,4,5):
    m=sd>t*robust
    print(t,m.mean())
m=sd>4*robust
m=mo.binary_closing(m,mo.disk(5));m=ndi.binary_fill_holes(m);m=mo.remove_small_objects(m,30);m=mo.binary_dilation(m,mo.disk(3))
print(m.mean())
lo,hi=np.percentile(d,[1,99]);b=np.clip((d-lo)/(hi-lo),0,1)
rgb=np.dstack([b]*3);rgb[segmentation.find_boundaries(m)]=[1,0,0]
io.imsave(f'{"'$S'"}/mask.png',(rgb*255).astype(np.uint8))
