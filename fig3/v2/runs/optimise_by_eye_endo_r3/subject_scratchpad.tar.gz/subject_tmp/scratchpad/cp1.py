import tifffile,numpy as np,time
from skimage import io,segmentation
from scipy import ndimage as ndi
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
d=a-ndi.gaussian_filter(a,50)
m=models.CellposeModel(gpu=False)
t=time.time()
for name,kw in [('d50',dict(diameter=50)),('dNone',dict(diameter=None))]:
    lab,flows,_=m.eval(d,normalize={'percentile':[1,99]},**kw)
    print(name,lab.max(),time.time()-t)
    np.save(f'{"/tmp/claude-0/-home-user-sessions-v2-v012/3bd3835f-954c-4ca6-99e2-18230cc941b5/scratchpad"}/lab_{name}.npy',lab)
    lo,hi=np.percentile(d,[1,99]);b=np.clip((d-lo)/(hi-lo),0,1)
    rgb=np.dstack([b]*3);rgb[segmentation.find_boundaries(lab,mode='inner')]=[1,0,0]
    io.imsave(f'/tmp/claude-0/-home-user-sessions-v2-v012/3bd3835f-954c-4ca6-99e2-18230cc941b5/scratchpad/ov_{name}.png',(rgb*255).astype(np.uint8))
