import sys,tifffile,numpy as np
from skimage import io,segmentation,measure
a=tifffile.imread('image.tif').astype(float); m=np.load(sys.argv[1]); thr=float(sys.argv[2])
b=np.clip(a/np.percentile(a,99.8),0,1)**0.6
rgb=np.dstack([b]*3)
for r in measure.regionprops(m,a):
    mk=m==r.label
    bd=mk&~segmentation.binary_erosion(mk) if False else segmentation.find_boundaries(mk,mode='inner')
    rgb[bd]=[1,0.1,0.1] if r.intensity_mean<thr else [0.1,1,0.1]
x0,y0,w=map(int,sys.argv[4:7])
c=(rgb[y0:y0+w,x0:x0+w]*255).astype('uint8')
c=np.kron(c,np.ones((1024//w,1024//w,1),dtype='uint8'))
io.imsave(sys.argv[3],c)
