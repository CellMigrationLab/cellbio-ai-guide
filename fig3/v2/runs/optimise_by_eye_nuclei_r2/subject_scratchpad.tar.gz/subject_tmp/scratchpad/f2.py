import tifffile,numpy as np,pandas as pd
from skimage.measure import regionprops_table
a=tifffile.imread('image.tif').astype(float);l=np.load('/tmp/claude-0/-home-user-sessions-v2-v006/3b6ad864-d583-4e54-9468-6e4fb791da0d/scratchpad/l4.npy')
d=pd.DataFrame(regionprops_table(l,a,properties=('label','area','centroid','axis_major_length','axis_minor_length','intensity_mean')))
d['ar']=d.axis_major_length/d.axis_minor_length
d['x']=d['centroid-1'].round();d['y']=d['centroid-0'].round()
print(np.histogram(d.intensity_mean,bins=[0,300,400,500,600,700,800,900,1000,1200,1500,2000,5000]))
b=d[d.intensity_mean>800].sort_values('intensity_mean')
print(b[['label','x','y','area','ar','intensity_mean']].to_string())
