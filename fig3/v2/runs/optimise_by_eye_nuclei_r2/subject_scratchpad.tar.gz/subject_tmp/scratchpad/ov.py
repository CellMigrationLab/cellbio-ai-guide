import sys,tifffile,numpy as np
from skimage import io,segmentation,measure
a=tifffile.imread('image.tif').astype(float)
m=tifffile.imread(sys.argv[1]) if sys.argv[1].endswith('tif') else np.load(sys.argv[1])
b=np.clip(a/np.percentile(a,99.8),0,1)**0.6
rgb=np.dstack([b]*3)
bd=segmentation.find_boundaries(m,mode='inner')
rgb[bd]=[1,0.1,0.1]
rgb=(rgb*255).astype('uint8')
x0,y0,w=int(sys.argv[3]),int(sys.argv[4]),int(sys.argv[5])
c=rgb[y0:y0+w,x0:x0+w]
from skimage.transform import resize
c=np.kron(c,np.ones((1024//w,1024//w,1),dtype='uint8')) if w<1024 else c
io.imsave(sys.argv[2],c)
