import sys,tifffile,numpy as np
from skimage import io,segmentation
a=tifffile.imread('image.tif').astype(float)
l=np.load(sys.argv[1]) if sys.argv[1].endswith('npy') else tifffile.imread(sys.argv[1])
b=np.clip(a/np.percentile(a,99.8),0,1)**0.6
big=np.kron(b,np.ones((2,2)));lb=np.kron(l,np.ones((2,2),int))
o=segmentation.mark_boundaries(np.dstack([big]*3),lb,color=(1,0,0),mode='inner')
o=(o*255).astype('uint8')
io.imsave(sys.argv[2]+'_a.png',o[:1024,:1024]);io.imsave(sys.argv[2]+'_b.png',o[1024:,1024:])
