import tifffile,numpy as np,time
from cellpose import models
from skimage import morphology,filters
S='/tmp/claude-0/-home-user-sessions-v2-v006/3b6ad864-d583-4e54-9468-6e4fb791da0d/scratchpad/'
a=tifffile.imread('image.tif').astype(np.float32)
g=filters.gaussian(a,1,preserve_range=True)
bg=morphology.opening(g,morphology.disk(20))
bg=filters.gaussian(bg,10,preserve_range=True)
x=np.clip(a-bg,0,None)
hi=np.percentile(x,99.0);x=np.clip(x/hi,0,1.5)**1.5
m=models.CellposeModel(gpu=False)
l=m.eval(x,batch_size=4,normalize=False)[0]
print(l.max());np.save(S+'l4.npy',l)
