import tifffile,numpy as np,time
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
m=models.CellposeModel(gpu=False,pretrained_model='cpsam_v2')
t=time.time()
masks,_,_=m.eval(a,batch_size=4,normalize={'percentile':[1,99.5]})
print(time.time()-t,masks.max())
np.save('/tmp/claude-0/-home-user-sessions-v2-v006/5299631d-348e-4b44-a076-8c7d1bb265a7/scratchpad/m1.npy',masks)
