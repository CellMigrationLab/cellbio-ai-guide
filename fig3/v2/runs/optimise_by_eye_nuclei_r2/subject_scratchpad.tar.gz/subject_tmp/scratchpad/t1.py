import tifffile,numpy as np,time
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
lo,hi=np.percentile(a,[1,99.5]);x=np.clip((a-lo)/(hi-lo),0,1)
m=models.CellposeModel(gpu=False)
t=time.time()
l,f,s=m.eval(x,batch_size=4,normalize=False)[:3]
print(time.time()-t,l.max())
np.save('/tmp/claude-0/-home-user-sessions-v2-v006/3b6ad864-d583-4e54-9468-6e4fb791da0d/scratchpad/l1.npy',l)
from skimage.measure import regionprops
r=regionprops(l,a)
import numpy as np
print(np.percentile([p.area for p in r],[5,25,50,75,95]),np.percentile([p.mean_intensity for p in r],[5,25,50,75,95]))
