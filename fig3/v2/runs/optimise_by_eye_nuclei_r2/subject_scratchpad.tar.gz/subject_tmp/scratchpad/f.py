import tifffile,numpy as np,pandas as pd
from skimage.measure import regionprops_table
a=tifffile.imread('image.tif').astype(float);l=np.load('/tmp/claude-0/-home-user-sessions-v2-v006/3b6ad864-d583-4e54-9468-6e4fb791da0d/scratchpad/l1.npy')
d=pd.DataFrame(regionprops_table(l,a,properties=('label','area','centroid','axis_major_length','axis_minor_length','solidity','intensity_mean','intensity_max')))
d['ar']=d.axis_major_length/d.axis_minor_length
d['side']=np.where(d['centroid-1']<512,'L','R')
print(d.groupby('side')[['area','ar','solidity','intensity_mean']].describe().T.to_string())
print(np.histogram(d.intensity_mean,bins=[0,300,400,500,600,700,800,1000,1300,1700,2500,5000]))
d.to_csv(__import__('sys').argv[1] if len(__import__('sys').argv)>1 else '/dev/null')
