import sys,numpy as np,tifffile as t,time
from scipy import ndimage as ndi
from skimage import io,segmentation,exposure
from cellpose import models
a=t.imread('image.tif').astype(np.float32)
bg=ndi.gaussian_filter(a,60)
f=a-bg
sd=np.sqrt(ndi.gaussian_filter(f**2,60)); f=f/sd
f=ndi.gaussian_filter(f,1.0)
np.save(sys.argv[1]+'_f.npy',f)
m=models.CellposeModel(gpu=False)
for d in [float(x) for x in sys.argv[2:]]:
    t0=time.time()
    lab,_,_=m.eval(f,diameter=d,flow_threshold=0.4,cellprob_threshold=0.0)
    print(d,lab.max(),time.time()-t0,np.median(np.bincount(lab.ravel())[1:])*0.65**2)
    np.save(f'{sys.argv[1]}_lab{int(d)}.npy',lab)
    v=np.clip((f+3)/6,0,1)
    o=segmentation.mark_boundaries(np.dstack([v]*3),lab,color=(1,0,0))
    io.imsave(f'{sys.argv[1]}_ov{int(d)}.png',(o*255).astype(np.uint8))
