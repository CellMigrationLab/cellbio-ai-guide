S='/tmp/claude-0/-home-user-sessions-v2-v015/659e727e-9a55-4330-8e31-92fb9a18a250/scratchpad'
import numpy as np,tifffile as t
from scipy import ndimage as ndi
from skimage import morphology as mo,io,segmentation,filters
a=t.imread('image.tif').astype(np.float32)
hp=a-ndi.gaussian_filter(a,25)
s=np.sqrt(ndi.gaussian_filter(hp**2,4))
print(np.percentile(s,[50,75,90,95]),filters.threshold_otsu(s))
for th in [90,110]:
    m=s>th
    m=ndi.binary_fill_holes(m); m=mo.opening(m,mo.disk(9)); m=mo.remove_small_objects(m,300)
    print(th,ndi.label(m)[1])
    lab=np.load(S+'/e_lab70.npy')
    v=np.clip((a-ndi.gaussian_filter(a,40))/700+.5,0,1);o=np.dstack([v]*3)
    o[segmentation.find_boundaries(m)]=(1,0,0)
    o[segmentation.find_boundaries(lab,mode='inner')]=(1,1,0)
    io.imsave(f'{S}/cm{th}.png',(o*255).astype(np.uint8))
