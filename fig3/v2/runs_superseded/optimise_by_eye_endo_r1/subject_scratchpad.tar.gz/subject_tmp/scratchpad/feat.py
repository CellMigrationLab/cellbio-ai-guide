S='/tmp/claude-0/-home-user-sessions-v2-v015/659e727e-9a55-4330-8e31-92fb9a18a250/scratchpad'
import numpy as np,tifffile as t
from scipy import ndimage as ndi
from skimage import measure,io,segmentation
a=t.imread('image.tif').astype(np.float32)
lab=np.load('/tmp/claude-0/-home-user-sessions-v2-v015/659e727e-9a55-4330-8e31-92fb9a18a250/scratchpad/e_lab70.npy')
hp=a-ndi.gaussian_filter(a,25)
gm=ndi.gaussian_gradient_magnitude(a,1.5)
rows=[]
for r in measure.regionprops(lab):
    m=lab==r.label
    rows.append((r.label,r.area*.4225,r.solidity,r.eccentricity,hp[m].std(),gm[m].mean(),np.percentile(hp[m],2)))
rows=np.array(rows)
np.save(S+'/feat.npy',rows)
print(np.percentile(rows[:,4],[10,50,75,90,95]),np.percentile(rows[:,5],[10,50,75,90,95]))
# overlay with labels colored by gm
v=np.clip((a-ndi.gaussian_filter(a,40))/700+.5,0,1)
o=np.dstack([v]*3)
b=segmentation.find_boundaries(lab,mode='inner')
o[b]=(1,1,0)
io.imsave(S+'/ov2.png',(o[:512,:512].repeat(2,0).repeat(2,1)*255).astype(np.uint8))
for l,ar,so,ec,s,g,p in rows[np.argsort(rows[:,5])[-40:]]: print(int(l),int(ar),round(so,2),round(s),round(g))
