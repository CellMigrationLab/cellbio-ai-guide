import tifffile,numpy as np,sys,time
from scipy import ndimage as ndi
from skimage import io,segmentation,color,transform
from cellpose import models
a=tifffile.imread('image.tif').astype(np.float32)
# flatten: subtract large-scale background per pixel (handles seam)
bg=ndi.gaussian_filter(ndi.median_filter(a[::4,::4],size=15),8)
bg=transform.resize(bg,a.shape,order=1)
f=a-bg
f=ndi.gaussian_filter(f,1)
lo,hi=np.percentile(f,[1,99]);f=np.clip((f-lo)/(hi-lo),-0.5,1.5)
np.save('/tmp/claude-0/-home-user-sessions-v2-v028/ed0950ab-04e3-4ff8-a84c-4ab29a414d4e/scratchpad/flat.npy',f)
m=models.CellposeModel(gpu=False)
for d in [50,70]:
    t=time.time()
    r=m.eval(f,diameter=d,flow_threshold=0.4,cellprob_threshold=-1,normalize=True)[0]
    print(d,r.max(),time.time()-t)
    np.save('/tmp/claude-0/-home-user-sessions-v2-v028/ed0950ab-04e3-4ff8-a84c-4ab29a414d4e/scratchpad/lab_%d.npy'%d,r)
    b=segmentation.mark_boundaries(np.clip(f*0.5+0.4,0,1),r,color=(1,0,0))
    io.imsave('/tmp/claude-0/-home-user-sessions-v2-v028/ed0950ab-04e3-4ff8-a84c-4ab29a414d4e/scratchpad/ov_%d.png'%d,(b*255).astype('uint8'))
