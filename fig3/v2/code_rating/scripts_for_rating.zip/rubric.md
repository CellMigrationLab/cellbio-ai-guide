Rate each script from 1 (poor) to 5 (excellent) on each item. Judge only what you can read; do not run the code.

1. Readability: can you follow the steps from input to output without effort?
2. Visible parameters: are the important choices (pixel size, model, diameters, thresholds, size limits) named and easy to find and change?
3. Debuggability: if the result were wrong, how easily could you find which step is responsible (separate steps, intermediate outputs, logging)?
4. Error handling: does it check its inputs and fail with an informative message, rather than silently continuing or guessing?
5. Testability: could you test or replace one step on its own?
6. Overall complexity (1 = far more complicated than needed, 5 = as simple as the task allows).
